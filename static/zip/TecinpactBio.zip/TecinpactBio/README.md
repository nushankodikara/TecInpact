# TecinpactBio

This is a quick and simple clone for instagram bio link section. With the growing popularity, and As a web developer, I made a simple bio alternative with Bootstrap 4 and JQuery. Also I implemented a XML RSS feed from my site as a quick addition.

use `-b` before image extension to get the dark icons

>       telegram.png    #Day Theme
>       telegram-b.png  #Night Theme

And Always remember if you're using XML RSS feed, you have to add this line of code to your `.htaccess` file in your server, or else you'll be greeted with a cute little CORS Error.

>       Access-Control-Allow-Origin: *

or 

>       Access-Control-Allow-Origin: https://your.hosting.url

As shown in [This Guide](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin)