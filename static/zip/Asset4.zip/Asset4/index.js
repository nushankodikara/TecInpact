$(".wrapper").css({
    display: "none"
});
let modalStat = 0;

butotnFunction = () => {
    if (modalStat == 0) {
        $(".wrapper").fadeIn(500);
        modalStat = 1;
    } else {
        $(".wrapper").fadeOut(500);
        modalStat = 0;
    }
}