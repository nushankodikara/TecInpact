/* A Simple Function to push new data */
postData = () => {
    let gitem = document.getElementById("Grocery").value
    let gqty = document.getElementById("QTY").value
    /* Resetting Input Boxes after submission */
    document.getElementById("Grocery").value = ""
    document.getElementById("QTY").value = 0
    /* Pushing data to the Database's GroceryList Directory */
    let newItem = firebase.database().ref('/GroceryList/').push();
    newItem.set({
        item: gitem,
        qty: gqty
    });
}

/* Listner to get data from the Database As soon as it's added */
let items = firebase.database().ref('GroceryList/');
items.on('value', function (recivedItems) {
    /* Appends data to an array and then we can set the whole array to the table */
    let htmlArray = [`<tr><th>Items</th><th>QTY</th><th>Got It?</th></tr>`]
    recivedItems.forEach(item => {
        /* Formatting Received Data */
        htmlArray.push(`<tr><td>${item.val()["item"]}</td><td>${item.val()["qty"]}</td><td><button onclick="removedList('${item.key}')">✔️</button></td></tr>`)
    });
    /* Setting Data to table */
    document.getElementById('table').innerHTML = htmlArray.join('')
});

/* Adding data to another list when completed */
removedList = (id) => {
    let item = firebase.database().ref(`GroceryList/${id}`)
    item.on('value', function (snapshot) {
        /* Getting data and submitting it to Removed List */
        let newCompletedItem = firebase.database().ref('/GroceryRemovedList/').push();
        newCompletedItem.set(snapshot.val());
    });
    /* Removing from the first list */
    removeEntity("GroceryList", `${id}`)
}

/* Listner for the completed List */
let ritems = firebase.database().ref('GroceryRemovedList/');
ritems.on('value', function (recivedItems) {
    let htmlArray = [`<tr><th>Items</th><th>QTY</th><th>Remove It?</th></tr>`]
    recivedItems.forEach(item => {
        htmlArray.push(`<tr><td style="text-decoration: line-through;">${item.val()["item"]}</td><td>${item.val()["qty"]}</td><td><button onclick="removeEntity('GroceryRemovedList','${item.key}')">❌</button></td></tr>`)
    });
    document.getElementById('table2').innerHTML = htmlArray.join('')
});

/* This can delete items from the database */
removeEntity = (list, id) => {
    firebase.database().ref(`${list}/${id}`).remove()
}