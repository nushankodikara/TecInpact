// This makes easier to hide and show chat window based on login status
let chatview = 1
// Login Provider
let provider = new firebase.auth.GoogleAuthProvider();

// Show and hide Chat window and others based on login status
chattoggle = () => {
    if (chatview == 0) {
        $(".chatbody").css("display", "flex").hide().fadeIn();
        $(".login").css("display", "grid").hide().fadeOut();
        $(".sendmessage").css("display", "grid").hide().fadeIn();
        $("#sout").fadeIn();
        chatview = 1
    } else {
        $(".chatbody").css("display", "flex").hide().fadeOut();
        $(".login").css("display", "grid").hide().fadeIn();
        $(".sendmessage").css("display", "grid").hide().fadeOut();
        $("#sout").fadeOut();
        chatview = 0
    }
}

// Initializing First Run
chattoggle();

// Login With Google when pressed the button
googleLogin = () => {
    firebase.auth().signInWithPopup(provider).then(function (result) {}).catch(function (error) {});
}

// Send messages
sendMsg = () => {
    message = $('#message').val()
    $('#message').val('')
    if (message) {
        sendData(message, username)
    }
}

// Defining username
let username;

// Authentication listener , this triggers when auth state changed
firebase.auth().onAuthStateChanged(function (user) {
    if (user) {
        chattoggle();
        loadData();
        username = user.displayName
    } else {

    }
});

// A Sign out function
signOut = () => {
    firebase.auth().signOut().then(function () {
        chattoggle();
    }).catch(function (error) {});
}

// Pushes data to the database
sendData = (message, author) => {
    let newPostRef = firebase.database().ref('messageList1').push();
    newPostRef.set({
        msg: message,
        aut: author
    });
}

// Loads data from the database realtime
loadData = () => {
    let msgList = firebase.database().ref('messageList1');
    msgList.on('value', function (snapshot) {
        let html = []
        snapshot.forEach(element => {
            // I Have a strategy to minimize latency, First putting everything we need to add to our HTML Document to a array and finally appending the whole array to the document at once
            if (username == element.val()['aut']) {
                html.push(`
            <div class="mcard">
                <b>${purge(element.val()['aut'])}</b>
                <p>${purge(element.val()['msg'])}</p>
            </div>`)
            } else {
                html.push(`
            <div class="card">
                <b>${purge(element.val()['aut'])}</b>
                <p>${purge(element.val()['msg'])}</p>
            </div>`)
            }
        });
        $(".messagebox").html(html.join(''))
        document.getElementById('messagebox').scrollIntoView(false);
    });
}

// This is a little security feature to make it fool proof And prevent cross site scripting. Also adding a limit to the purge.
purge = (string) => {
    let newStr = (string).replace(/<|>/g, "").substring(0, 256);
    return (newStr)
}